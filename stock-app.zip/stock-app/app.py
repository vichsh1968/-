# -*- coding: utf-8 -*-
"""
股票突破/跌破檢查工具
打開後按「重新檢查」，會抓你清單裡每一檔股票的最近日線資料，
判斷目前價格是否符合你設定的四種條件。

條件定義（可在左側調整參數）：
 1. 跌破前 N 天低點：目前價 < 前 N 個交易日(不含今天)的最低點
 2. 突破前 N 天高點：目前價 > 前 N 個交易日(不含今天)的最高點
 3. 跌破大量日低點：在「量能觀察天數」內，找出成交量 >= 平均量 x 倍數 的「大量日」，
                    取其中成交量最大那一天，目前價 < 那天的低點
 4. 突破大量日高點：同上，目前價 > 那天最大量日的高點
"""

import datetime as dt
import pandas as pd


# ----------------------------------------------------------------------
# 純邏輯：給一段日線資料 (DataFrame) 與參數，回傳判斷結果。可單獨測試。
# df 需含欄位 Open/High/Low/Close/Volume，且依日期由舊到新排序。
# ----------------------------------------------------------------------
def evaluate(df: pd.DataFrame, current_price: float,
             hl_lookback: int = 2, vol_lookback: int = 10,
             vol_mult: float = 1.5) -> dict:
    df = df.dropna(subset=["High", "Low", "Volume"]).copy()
    if len(df) < hl_lookback + 1:
        return {"error": "資料天數不足"}

    prev = df.iloc[:-1]                       # 不含最後一根(視為今天)
    prevN = prev.iloc[-hl_lookback:]          # 前 N 個交易日
    prev_low = float(prevN["Low"].min())
    prev_high = float(prevN["High"].max())

    # 量能視窗
    vol_win = prev.iloc[-vol_lookback:]
    avg_vol = float(vol_win["Volume"].mean())
    threshold = avg_vol * vol_mult
    big_days = vol_win[vol_win["Volume"] >= threshold]
    if len(big_days) == 0:                    # 沒有達標的就退而取量最大那天
        big_days = vol_win
    big_day = big_days.loc[big_days["Volume"].idxmax()]
    big_low = float(big_day["Low"])
    big_high = float(big_day["High"])
    big_date = big_day.name

    return {
        "current": float(current_price),
        "prev_low": prev_low,
        "prev_high": prev_high,
        "big_date": big_date,
        "big_low": big_low,
        "big_high": big_high,
        "big_vol": float(big_day["Volume"]),
        "avg_vol": avg_vol,
        "break_below_prev": current_price < prev_low,
        "break_above_prev": current_price > prev_high,
        "break_below_big": current_price < big_low,
        "break_above_big": current_price > big_high,
    }


# ----------------------------------------------------------------------
# 以下是 Streamlit 介面，只有實際執行 app 時才會用到。
# ----------------------------------------------------------------------
def _run_app():
    import streamlit as st
    import yfinance as yf

    st.set_page_config(page_title="股票突破/跌破檢查", page_icon="📈", layout="wide")
    st.title("📈 我的股票條件檢查")
    st.caption("打開或按下方按鈕時會重新抓資料檢查。資料為 Yahoo 來源、可能延遲約 15 分鐘，不是即時逐筆。")

    with st.sidebar:
        st.header("⚙️ 設定")
        st.markdown(
            "**股票代號**（一行一檔）\n\n"
            "台股加 `.TW`（上市）或 `.TWO`（上櫃），美股直接打代號。"
        )
        default_list = "2330.TW\n2317.TW\nAAPL"
        tickers_text = st.text_area("清單", value=default_list, height=160)
        hl_lookback = st.number_input("前幾天高/低點 (N)", 1, 10, 2)
        vol_lookback = st.number_input("量能觀察天數", 3, 30, 10)
        vol_mult = st.slider("大量門檻 (平均量的幾倍)", 1.0, 3.0, 1.5, 0.1)
        refresh = st.button("🔄 重新檢查", type="primary", use_container_width=True)

    tickers = [t.strip().upper() for t in tickers_text.splitlines() if t.strip()]

    @st.cache_data(ttl=300, show_spinner=False)
    def fetch(ticker: str) -> pd.DataFrame:
        df = yf.Ticker(ticker).history(period="2mo", interval="1d")
        return df[["Open", "High", "Low", "Close", "Volume"]]

    if refresh:
        fetch.clear()

    if not tickers:
        st.info("請在左側輸入至少一檔股票代號。")
        return

    st.write(f"最後檢查時間：{dt.datetime.now():%Y-%m-%d %H:%M:%S}")

    hits, rows = [], []
    progress = st.progress(0.0, text="抓取資料中…")
    for i, tk in enumerate(tickers):
        try:
            df = fetch(tk)
            if df.empty:
                rows.append({"代號": tk, "狀態": "查無資料"})
                continue
            current = float(df["Close"].iloc[-1])
            r = evaluate(df, current, hl_lookback, vol_lookback, vol_mult)
            if "error" in r:
                rows.append({"代號": tk, "狀態": r["error"]})
                continue

            triggered = []
            if r["break_below_prev"]:
                triggered.append(f"跌破前{hl_lookback}日低 {r['prev_low']:.2f}")
            if r["break_above_prev"]:
                triggered.append(f"突破前{hl_lookback}日高 {r['prev_high']:.2f}")
            if r["break_below_big"]:
                triggered.append(f"跌破大量日低 {r['big_low']:.2f}")
            if r["break_above_big"]:
                triggered.append(f"突破大量日高 {r['big_high']:.2f}")
            if triggered:
                hits.append(f"**{tk}**（現價 {current:.2f}）→ " + "、".join(triggered))

            rows.append({
                "代號": tk,
                "現價": round(current, 2),
                f"前{hl_lookback}日低": round(r["prev_low"], 2),
                f"前{hl_lookback}日高": round(r["prev_high"], 2),
                "跌破低": "🔻" if r["break_below_prev"] else "",
                "突破高": "🔺" if r["break_above_prev"] else "",
                "大量日": str(r["big_date"])[:10],
                "大量低": round(r["big_low"], 2),
                "大量高": round(r["big_high"], 2),
                "破量低": "🔻" if r["break_below_big"] else "",
                "破量高": "🔺" if r["break_above_big"] else "",
            })
        except Exception as e:  # noqa
            rows.append({"代號": tk, "狀態": f"錯誤：{e}"})
        progress.progress((i + 1) / len(tickers), text=f"已檢查 {i+1}/{len(tickers)}")
    progress.empty()

    if hits:
        st.success("🚨 有股票符合條件：")
        for h in hits:
            st.markdown("- " + h)
    else:
        st.info("目前沒有股票符合設定條件。")

    st.subheader("全部明細")
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


if __name__ == "__main__":
    _run_app()
