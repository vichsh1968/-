# 股票條件檢查工具

打開後依設定檢查持股是否突破/跌破條件，並顯示 EMA 排列與金叉死叉。

- `stock-checker.html` — 網頁版（雙擊或放到網站開）。版本號顯示在標題與頁尾。
- `app.py` / `requirements.txt` — 伺服器版（可部署到 Streamlit Cloud，無中繼/CORS 問題）。
- `CHANGELOG.md` — 版本變更紀錄。

## 版本控管
本資料夾是一個 git 專案。建議上傳到 GitHub：
- 自動保留每次修改的歷史，隨時可回到舊版。
- 開啟 GitHub Pages 後得到 https 網址，能改善網頁版「Failed to fetch」的問題。
- 也可直接從 repo 一鍵部署到 Streamlit Cloud。
